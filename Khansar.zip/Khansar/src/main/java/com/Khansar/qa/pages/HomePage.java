package com.Khansar.qa.pages;

import com.Khansar.qa.base.TestBase;

public class HomePage extends TestBase {
   public   HomePage homePage;
}
